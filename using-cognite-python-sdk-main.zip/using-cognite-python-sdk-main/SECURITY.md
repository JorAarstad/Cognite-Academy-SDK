# Security Policy

## Supported Versions

All versions are supported

## Reporting a Vulnerability

Send an incident report on https://cog.link/ask-security or send an email to security@cognite.com
